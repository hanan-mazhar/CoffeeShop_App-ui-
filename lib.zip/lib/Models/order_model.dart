class OrderItem {
  final String coffeeId;
  final String coffeeName;
  final String coffeeImage;
  final double price;
  int quantity;

  OrderItem({
    required this.coffeeId,
    required this.coffeeName,
    required this.coffeeImage,
    required this.price,
    this.quantity = 1,
  });

  Map<String, dynamic> toMap() => {
        'coffeeId': coffeeId,
        'coffeeName': coffeeName,
        'coffeeImage': coffeeImage,
        'price': price,
        'quantity': quantity,
      };

  factory OrderItem.fromMap(Map<String, dynamic> map) => OrderItem(
        coffeeId: map['coffeeId'] ?? '',
        coffeeName: map['coffeeName'] ?? '',
        coffeeImage: map['coffeeImage'] ?? '',
        price: (map['price'] ?? 0).toDouble(),
        quantity: map['quantity'] ?? 1,
      );
}

class OrderModel {
  final String id;
  final String userId;
  final String userName;
  final String userAddress;
  final String userPhone;
  final List<OrderItem> items;
  final double totalAmount;
  final String status;
  final DateTime createdAt;
  final String? estimatedDelivery;

  // Payment fields
  final String paymentMethod;  // 'cod' ya 'card'
  final String paymentStatus;  // 'pending' ya 'paid' ya 'failed'
  final String? paymentIntentId;
  final DateTime? paidAt;

  OrderModel({
    required this.id,
    required this.userId,
    required this.userName,
    required this.userAddress,
    required this.userPhone,
    required this.items,
    required this.totalAmount,
    required this.status,
    required this.createdAt,
    this.estimatedDelivery,
    this.paymentMethod = 'cod',
    this.paymentStatus = 'pending',
    this.paymentIntentId,
    this.paidAt,
  });

  factory OrderModel.fromMap(Map<String, dynamic> map, String id) {
    return OrderModel(
      id: id,
      userId: map['userId'] ?? '',
      userName: map['userName'] ?? '',
      userAddress: map['userAddress'] ?? '',
      userPhone: map['userPhone'] ?? '',
      items: (map['items'] as List<dynamic>? ?? [])
          .map((e) => OrderItem.fromMap(e))
          .toList(),
      totalAmount: (map['totalAmount'] ?? 0).toDouble(),
      status: map['status'] ?? 'pending',
      createdAt: map['createdAt'] != null
          ? DateTime.fromMillisecondsSinceEpoch(map['createdAt'])
          : DateTime.now(),
      estimatedDelivery: map['estimatedDelivery'],
      paymentMethod: map['paymentMethod'] ?? 'cod',
      paymentStatus: map['paymentStatus'] ?? 'pending',
      paymentIntentId: map['paymentIntentId'],
      paidAt: map['paidAt'] != null
          ? DateTime.fromMillisecondsSinceEpoch(map['paidAt'])
          : null,
    );
  }

  Map<String, dynamic> toMap() => {
        'userId': userId,
        'userName': userName,
        'userAddress': userAddress,
        'userPhone': userPhone,
        'items': items.map((e) => e.toMap()).toList(),
        'totalAmount': totalAmount,
        'status': status,
        'createdAt': createdAt.millisecondsSinceEpoch,
        'estimatedDelivery': estimatedDelivery,
        'paymentMethod': paymentMethod,
        'paymentStatus': paymentStatus,
        'paymentIntentId': paymentIntentId,
        'paidAt': paidAt?.millisecondsSinceEpoch,
      };
}
