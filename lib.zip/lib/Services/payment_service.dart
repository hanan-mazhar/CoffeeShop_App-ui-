import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:flutter/material.dart';
import 'package:flutter_stripe/flutter_stripe.dart';
import 'package:http/http.dart' as http;
import 'dart:convert';

class PaymentService {
  final FirebaseFirestore _db = FirebaseFirestore.instance;

  static const String _secretKey      = 'sk_test_51TUkTnBzahsslUrXsCTNUGyp1KzarzD3sOaNeUeUzceHI9FS6qVW8lCiyJCEep6Fg5wwLjgpFSD36SA2iXWfYgui00ta6VchUX';
  static const String _publishableKey = 'pk_test_51TUkTnBzahsslUrXdbnz21sKLgSo1o0Fnu6NHg6zsYA69RricXLEceTt5eXvIS90BR10aje5oZTM8cBW2YlmTgQr00jslxo5BT';

  static void init() {
    Stripe.publishableKey = _publishableKey;
  }

  Future<String?> _createPaymentIntent(double amountPKR) async {
    try {
      final response = await http.post(
        Uri.parse('https://api.stripe.com/v1/payment_intents'),
        headers: {
          'Authorization': 'Bearer $_secretKey',
          'Content-Type': 'application/x-www-form-urlencoded',
        },
        body: {
          'amount': (amountPKR * 100).toInt().toString(),
          'currency': 'pkr',
          'payment_method_types[]': 'card',
        },
      );

      if (response.statusCode == 200) {
        final data = jsonDecode(response.body);
        return data['client_secret'];
      }
      return null;
    } catch (e) {
      return null;
    }
  }

  Future<PaymentResult> processPayment({
    required double amount,
    required String userId,
    required String orderId,
  }) async {
    try {
      final clientSecret = await _createPaymentIntent(amount);
      if (clientSecret == null) {
        return PaymentResult.failed('Payment shuru nahi ho saka. Dobara koshish karein.');
      }

      await Stripe.instance.initPaymentSheet(
        paymentSheetParameters: SetupPaymentSheetParameters(
          paymentIntentClientSecret: clientSecret,
          merchantDisplayName: 'Coffee Shop ☕',
          style: ThemeMode.dark,
          appearance: const PaymentSheetAppearance(
            colors: PaymentSheetAppearanceColors(
              primary: Color(0xFFFF5722),
              background: Color(0xFF1a0a00),
              componentBackground: Color(0xFF2d1a00),
              primaryText: Color(0xFFFFFFFF),
              secondaryText: Color(0xFFAAAAAA),
            ),
            shapes: PaymentSheetShape(borderRadius: 14),
          ),
        ),
      );

      await Stripe.instance.presentPaymentSheet();

      final paymentIntentId = clientSecret.split('_secret_').first;

      await _db.collection('payments').add({
        'userId': userId,
        'orderId': orderId,
        'amount': amount,
        'currency': 'PKR',
        'paymentIntentId': paymentIntentId,
        'status': 'succeeded',
        'method': 'card',
        'createdAt': DateTime.now().millisecondsSinceEpoch,
      });

      await _db.collection('orders').doc(orderId).update({
        'paymentStatus': 'paid',
        'paymentMethod': 'card',
        'paymentIntentId': paymentIntentId,
        'paidAt': DateTime.now().millisecondsSinceEpoch,
      });

      return PaymentResult.success(paymentIntentId);
    } on StripeException catch (e) {
      return PaymentResult.failed(
          e.error.localizedMessage ?? 'Payment cancel ho gayi.');
    } catch (e) {
      return PaymentResult.failed('Payment nahi hui. Dobara koshish karein.');
    }
  }

  Stream<List<PaymentRecord>> getUserPayments(String userId) {
    return _db
        .collection('payments')
        .where('userId', isEqualTo: userId)
        .snapshots()
        .map((snap) {
      final list = snap.docs
          .map((doc) => PaymentRecord.fromMap(doc.data(), doc.id))
          .toList();
      list.sort((a, b) => b.createdAt.compareTo(a.createdAt));
      return list;
    });
  }
}

class PaymentResult {
  final bool success;
  final String? paymentIntentId;
  final String? errorMessage;

  PaymentResult._({required this.success, this.paymentIntentId, this.errorMessage});

  factory PaymentResult.success(String id) =>
      PaymentResult._(success: true, paymentIntentId: id);
  factory PaymentResult.failed(String msg) =>
      PaymentResult._(success: false, errorMessage: msg);
}

class PaymentRecord {
  final String id;
  final String userId;
  final String orderId;
  final double amount;
  final String currency;
  final String paymentIntentId;
  final String status;
  final DateTime createdAt;

  PaymentRecord({
    required this.id,
    required this.userId,
    required this.orderId,
    required this.amount,
    required this.currency,
    required this.paymentIntentId,
    required this.status,
    required this.createdAt,
  });

  factory PaymentRecord.fromMap(Map<String, dynamic> map, String id) {
    return PaymentRecord(
      id: id,
      userId: map['userId'] ?? '',
      orderId: map['orderId'] ?? '',
      amount: (map['amount'] ?? 0).toDouble(),
      currency: map['currency'] ?? 'PKR',
      paymentIntentId: map['paymentIntentId'] ?? '',
      status: map['status'] ?? '',
      createdAt: DateTime.fromMillisecondsSinceEpoch(map['createdAt'] ?? 0),
    );
  }
}
