import 'dart:io';
import 'package:flutter/material.dart';
import 'package:image_picker/image_picker.dart';
import '../../Models/coffee_model.dart';
import '../../Models/order_model.dart';
import '../../Services/auth_service.dart';
import '../../Services/coffee_service.dart';
import '../../Services/order_service.dart';
import '../Auth/login_screen.dart';

class AdminPanelScreen extends StatefulWidget {
  const AdminPanelScreen({super.key});

  @override
  State<AdminPanelScreen> createState() => _AdminPanelScreenState();
}

class _AdminPanelScreenState extends State<AdminPanelScreen>
    with SingleTickerProviderStateMixin {
  late TabController _tabController;

  @override
  void initState() {
    super.initState();
    _tabController = TabController(length: 2, vsync: this);
    _tabController.addListener(() => setState(() {}));
  }

  @override
  void dispose() {
    _tabController.dispose();
    super.dispose();
  }

  Future<void> _logout() async {
    await AuthService().logout();
    if (!mounted) return;
    Navigator.pushAndRemoveUntil(context,
        MaterialPageRoute(builder: (_) => const LoginScreen()), (_) => false);
  }

  @override
  Widget build(BuildContext context) {
    final screenWidth = MediaQuery.of(context).size.width;

    return Scaffold(
      backgroundColor: const Color(0xFF1a0a00),
      appBar: AppBar(
        backgroundColor: const Color(0xFF2d1a00),
        title: Row(
          children: [
            Container(
              padding: const EdgeInsets.all(6),
              decoration: BoxDecoration(
                color: Colors.deepOrange.withOpacity(0.2),
                shape: BoxShape.circle,
              ),
              child: const Icon(Icons.admin_panel_settings,
                  color: Colors.deepOrange, size: 22),
            ),
            const SizedBox(width: 10),
            const Text('Admin Panel',
                style: TextStyle(
                    color: Colors.white, fontWeight: FontWeight.bold)),
          ],
        ),
        actions: [
          IconButton(
            icon: const Icon(Icons.logout, color: Colors.deepOrange),
            onPressed: _logout,
          ),
        ],
        bottom: TabBar(
          controller: _tabController,
          labelColor: Colors.deepOrange,
          unselectedLabelColor: Colors.white54,
          indicatorColor: Colors.deepOrange,
          tabs: const [
            Tab(icon: Icon(Icons.coffee), text: 'Coffee Menu'),
            Tab(icon: Icon(Icons.receipt_long), text: 'Orders'),
          ],
        ),
      ),
      body: TabBarView(
        controller: _tabController,
        children: [
          const _CoffeeManagementTab(),
          const _OrderManagementTab(),
        ],
      ),
      floatingActionButton: _tabController.index == 0
          ? FloatingActionButton.extended(
              onPressed: () => showDialog(
                  context: context,
                  builder: (_) => const _AddCoffeeDialog()),
              backgroundColor: Colors.deepOrange,
              icon: const Icon(Icons.add, color: Colors.white),
              label: Text(
                screenWidth < 360 ? 'Add' : 'Add Coffee',
                style: const TextStyle(color: Colors.white),
              ),
            )
          : null,
    );
  }
}

// ---- Coffee Management ----
class _CoffeeManagementTab extends StatelessWidget {
  const _CoffeeManagementTab();

  @override
  Widget build(BuildContext context) {
    return StreamBuilder<List<CoffeeModel>>(
      stream: CoffeeService().getCoffees(),
      builder: (context, snap) {
        if (snap.connectionState == ConnectionState.waiting) {
          return const Center(
              child: CircularProgressIndicator(color: Colors.deepOrange));
        }
        final coffees = snap.data ?? [];
        if (coffees.isEmpty) {
          return const Center(
              child: Text('No coffee items. Add one!',
                  style: TextStyle(color: Colors.white54)));
        }
        return ListView.builder(
          padding: const EdgeInsets.all(16),
          itemCount: coffees.length,
          itemBuilder: (context, i) =>
              _AdminCoffeeCard(coffee: coffees[i]),
        );
      },
    );
  }
}

class _AdminCoffeeCard extends StatelessWidget {
  final CoffeeModel coffee;
  const _AdminCoffeeCard({required this.coffee});

  @override
  Widget build(BuildContext context) {
    return Container(
      margin: const EdgeInsets.only(bottom: 12),
      padding: const EdgeInsets.all(12),
      decoration: BoxDecoration(
        color: Colors.white.withOpacity(0.07),
        borderRadius: BorderRadius.circular(16),
        border: Border.all(color: Colors.white12),
      ),
      child: Row(
        children: [
          // Coffee image
          ClipRRect(
            borderRadius: BorderRadius.circular(10),
            child: _buildImage(coffee.image, 65),
          ),
          const SizedBox(width: 12),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(coffee.name,
                    style: const TextStyle(
                        color: Colors.white,
                        fontWeight: FontWeight.bold,
                        fontSize: 15),
                    maxLines: 1,
                    overflow: TextOverflow.ellipsis),
                Text(coffee.type,
                    style:
                        const TextStyle(color: Colors.white54, fontSize: 12)),
                Text('\$${coffee.price.toStringAsFixed(2)}',
                    style: const TextStyle(
                        color: Colors.deepOrange, fontSize: 13)),
              ],
            ),
          ),
          // Available toggle
          Column(
            children: [
              Transform.scale(
                scale: 0.8,
                child: Switch(
                  value: coffee.isAvailable,
                  activeColor: Colors.deepOrange,
                  onChanged: (val) => CoffeeService()
                      .updateCoffee(coffee.id, {'isAvailable': val}),
                ),
              ),
              Text(
                coffee.isAvailable ? 'On' : 'Off',
                style: TextStyle(
                    color:
                        coffee.isAvailable ? Colors.green : Colors.red,
                    fontSize: 10),
              ),
            ],
          ),
          IconButton(
            icon: const Icon(Icons.edit_outlined,
                color: Colors.orange, size: 20),
            onPressed: () => showDialog(
                context: context,
                builder: (_) => _EditCoffeeDialog(coffee: coffee)),
          ),
          IconButton(
            icon: const Icon(Icons.delete_outline,
                color: Colors.red, size: 20),
            onPressed: () => _confirmDelete(context),
          ),
        ],
      ),
    );
  }

  Widget _buildImage(String path, double size) {
    // If it's a file path (from gallery)
    if (path.startsWith('/')) {
      return Image.file(File(path),
          width: size, height: size, fit: BoxFit.cover,
          errorBuilder: (_, __, ___) => _placeholder(size));
    }
    // Asset image
    return Image.asset(path,
        width: size, height: size, fit: BoxFit.cover,
        errorBuilder: (_, __, ___) => _placeholder(size));
  }

  Widget _placeholder(double size) {
    return Container(
        width: size,
        height: size,
        color: Colors.deepOrange.withOpacity(0.2),
        child: const Icon(Icons.coffee, color: Colors.deepOrange));
  }

  void _confirmDelete(BuildContext context) {
    showDialog(
      context: context,
      builder: (_) => AlertDialog(
        backgroundColor: const Color(0xFF2d1a00),
        title: const Text('Confirm Delete',
            style: TextStyle(color: Colors.white)),
        content: Text('Delete "${coffee.name}"? This cannot be undone.',
            style: const TextStyle(color: Colors.white70)),
        actions: [
          TextButton(
              onPressed: () => Navigator.pop(context),
              child: const Text('Cancel',
                  style: TextStyle(color: Colors.white54))),
          ElevatedButton(
            style:
                ElevatedButton.styleFrom(backgroundColor: Colors.red),
            onPressed: () {
              CoffeeService().deleteCoffee(coffee.id);
              Navigator.pop(context);
            },
            child: const Text('Delete',
                style: TextStyle(color: Colors.white)),
          ),
        ],
      ),
    );
  }
}

// ---- Add Coffee Dialog with Gallery Image Picker ----
class _AddCoffeeDialog extends StatefulWidget {
  const _AddCoffeeDialog();

  @override
  State<_AddCoffeeDialog> createState() => _AddCoffeeDialogState();
}

class _AddCoffeeDialogState extends State<_AddCoffeeDialog> {
  final _nameC = TextEditingController();
  final _priceC = TextEditingController();
  final _descC = TextEditingController();
  String _type = 'Hot Coffee';
  String _imagePath = 'assets/images/Coffee1.jpg'; // default asset
  File? _pickedFile;
  bool _saving = false;

  final _types = ['Hot Coffee', 'Cold Coffee', 'Desserts', 'Snacks'];
  final _assetImages = [
    'assets/images/Coffee1.jpg',
    'assets/images/Coffee2.jpg',
    'assets/images/Coffee3.jpg',
    'assets/images/Coffee4.jpg',
    'assets/images/Coffee5.jpg',
    'assets/images/Coffee6.jpg',
  ];

  Future<void> _pickImage() async {
    showModalBottomSheet(
      context: context,
      backgroundColor: const Color(0xFF2d1a00),
      shape: const RoundedRectangleBorder(
          borderRadius: BorderRadius.vertical(top: Radius.circular(20))),
      builder: (_) => SafeArea(
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            const SizedBox(height: 12),
            const Text('Select Image Source',
                style: TextStyle(
                    color: Colors.white,
                    fontSize: 16,
                    fontWeight: FontWeight.bold)),
            const SizedBox(height: 12),
            ListTile(
              leading: const Icon(Icons.photo_library, color: Colors.deepOrange),
              title: const Text('Gallery', style: TextStyle(color: Colors.white)),
              onTap: () async {
                Navigator.pop(context);
                final picked = await ImagePicker()
                    .pickImage(source: ImageSource.gallery, imageQuality: 70);
                if (picked != null && mounted) {
                  setState(() {
                    _pickedFile = File(picked.path);
                    _imagePath = picked.path;
                  });
                }
              },
            ),
            ListTile(
              leading: const Icon(Icons.camera_alt, color: Colors.deepOrange),
              title: const Text('Camera', style: TextStyle(color: Colors.white)),
              onTap: () async {
                Navigator.pop(context);
                final picked = await ImagePicker()
                    .pickImage(source: ImageSource.camera, imageQuality: 70);
                if (picked != null && mounted) {
                  setState(() {
                    _pickedFile = File(picked.path);
                    _imagePath = picked.path;
                  });
                }
              },
            ),
            const Divider(color: Colors.white12),
            const Padding(
              padding: EdgeInsets.only(left: 16, top: 4, bottom: 4),
              child: Align(
                alignment: Alignment.centerLeft,
                child: Text('Or choose a default image:',
                    style: TextStyle(color: Colors.white54, fontSize: 13)),
              ),
            ),
            SizedBox(
              height: 80,
              child: ListView.builder(
                scrollDirection: Axis.horizontal,
                padding: const EdgeInsets.symmetric(horizontal: 12),
                itemCount: _assetImages.length,
                itemBuilder: (_, i) => GestureDetector(
                  onTap: () {
                    setState(() {
                      _pickedFile = null;
                      _imagePath = _assetImages[i];
                    });
                    Navigator.pop(context);
                  },
                  child: Container(
                    margin: const EdgeInsets.only(right: 8),
                    decoration: BoxDecoration(
                      borderRadius: BorderRadius.circular(10),
                      border: Border.all(
                          color: _imagePath == _assetImages[i]
                              ? Colors.deepOrange
                              : Colors.transparent,
                          width: 2),
                    ),
                    child: ClipRRect(
                      borderRadius: BorderRadius.circular(10),
                      child: Image.asset(_assetImages[i],
                          width: 70, height: 70, fit: BoxFit.cover),
                    ),
                  ),
                ),
              ),
            ),
            const SizedBox(height: 16),
          ],
        ),
      ),
    );
  }

  void _save() async {
    if (_nameC.text.trim().isEmpty) {
      ScaffoldMessenger.of(context).showSnackBar(const SnackBar(
          content: Text('Please enter coffee name'),
          backgroundColor: Colors.deepOrange));
      return;
    }
    if (_priceC.text.trim().isEmpty) {
      ScaffoldMessenger.of(context).showSnackBar(const SnackBar(
          content: Text('Please enter price'),
          backgroundColor: Colors.deepOrange));
      return;
    }
    setState(() => _saving = true);
    final coffee = CoffeeModel(
      id: '',
      name: _nameC.text.trim(),
      image: _imagePath,
      price: double.tryParse(_priceC.text) ?? 0,
      type: _type,
      description: _descC.text.trim(),
    );
    await CoffeeService().addCoffee(coffee);
    if (mounted) Navigator.pop(context);
  }

  @override
  Widget build(BuildContext context) {
    return Dialog(
      backgroundColor: const Color(0xFF2d1a00),
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(20)),
      insetPadding:
          const EdgeInsets.symmetric(horizontal: 16, vertical: 24),
      child: SingleChildScrollView(
        padding: const EdgeInsets.all(20),
        child: Column(
          mainAxisSize: MainAxisSize.min,
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            const Text('Add New Coffee',
                style: TextStyle(
                    color: Colors.white,
                    fontSize: 20,
                    fontWeight: FontWeight.bold)),
            const SizedBox(height: 16),

            // Image picker
            GestureDetector(
              onTap: _pickImage,
              child: Container(
                width: double.infinity,
                height: 150,
                decoration: BoxDecoration(
                  color: Colors.white.withOpacity(0.06),
                  borderRadius: BorderRadius.circular(14),
                  border: Border.all(
                      color: Colors.deepOrange.withOpacity(0.5),
                      width: 1.5),
                ),
                child: _pickedFile != null
                    ? ClipRRect(
                        borderRadius: BorderRadius.circular(14),
                        child: Image.file(_pickedFile!,
                            fit: BoxFit.cover, width: double.infinity))
                    : _imagePath.startsWith('assets')
                        ? ClipRRect(
                            borderRadius: BorderRadius.circular(14),
                            child: Stack(
                              fit: StackFit.expand,
                              children: [
                                Image.asset(_imagePath, fit: BoxFit.cover),
                                Container(
                                  decoration: BoxDecoration(
                                    color: Colors.black38,
                                    borderRadius: BorderRadius.circular(14),
                                  ),
                                ),
                                const Center(
                                  child: Column(
                                    mainAxisSize: MainAxisSize.min,
                                    children: [
                                      Icon(Icons.edit,
                                          color: Colors.white, size: 28),
                                      SizedBox(height: 4),
                                      Text('Tap to change image',
                                          style: TextStyle(
                                              color: Colors.white70,
                                              fontSize: 13)),
                                    ],
                                  ),
                                ),
                              ],
                            ),
                          )
                        : const Column(
                            mainAxisAlignment: MainAxisAlignment.center,
                            children: [
                              Icon(Icons.add_photo_alternate,
                                  color: Colors.deepOrange, size: 40),
                              SizedBox(height: 8),
                              Text('Tap to select image',
                                  style: TextStyle(
                                      color: Colors.white60, fontSize: 14)),
                              Text('Gallery • Camera • Default',
                                  style: TextStyle(
                                      color: Colors.white38, fontSize: 12)),
                            ],
                          ),
              ),
            ),
            const SizedBox(height: 14),

            _field(_nameC, 'Coffee Name', Icons.coffee),
            const SizedBox(height: 10),
            _field(_priceC, 'Price (e.g. 3.50)', Icons.attach_money,
                keyboard: TextInputType.number),
            const SizedBox(height: 10),
            _field(_descC, 'Description', Icons.description, maxLines: 2),
            const SizedBox(height: 10),

            // Category dropdown
            Container(
              padding: const EdgeInsets.symmetric(horizontal: 12),
              decoration: BoxDecoration(
                borderRadius: BorderRadius.circular(10),
                border: Border.all(color: Colors.white24),
              ),
              child: DropdownButton<String>(
                value: _type,
                isExpanded: true,
                dropdownColor: const Color(0xFF2d1a00),
                style: const TextStyle(color: Colors.white),
                underline: const SizedBox(),
                icon: const Icon(Icons.arrow_drop_down, color: Colors.deepOrange),
                items: ['Hot Coffee', 'Cold Coffee', 'Desserts', 'Snacks']
                    .map((t) => DropdownMenuItem(value: t, child: Text(t)))
                    .toList(),
                onChanged: (v) => setState(() => _type = v!),
              ),
            ),
            const SizedBox(height: 20),

            Row(
              children: [
                Expanded(
                  child: OutlinedButton(
                    style: OutlinedButton.styleFrom(
                        side: const BorderSide(color: Colors.white24)),
                    onPressed: () => Navigator.pop(context),
                    child: const Text('Cancel',
                        style: TextStyle(color: Colors.white54)),
                  ),
                ),
                const SizedBox(width: 10),
                Expanded(
                  child: ElevatedButton(
                    style: ElevatedButton.styleFrom(
                        backgroundColor: Colors.deepOrange),
                    onPressed: _saving ? null : _save,
                    child: _saving
                        ? const SizedBox(
                            width: 20,
                            height: 20,
                            child: CircularProgressIndicator(
                                color: Colors.white, strokeWidth: 2))
                        : const Text('Add',
                            style: TextStyle(color: Colors.white)),
                  ),
                ),
              ],
            ),
          ],
        ),
      ),
    );
  }

  Widget _field(TextEditingController c, String label, IconData icon,
      {TextInputType? keyboard, int maxLines = 1}) {
    return TextField(
      controller: c,
      keyboardType: keyboard,
      maxLines: maxLines,
      style: const TextStyle(color: Colors.white),
      decoration: InputDecoration(
        labelText: label,
        labelStyle: const TextStyle(color: Colors.white54),
        prefixIcon: Icon(icon, color: Colors.deepOrange, size: 20),
        enabledBorder: OutlineInputBorder(
            borderRadius: BorderRadius.circular(10),
            borderSide: const BorderSide(color: Colors.white24)),
        focusedBorder: OutlineInputBorder(
            borderRadius: BorderRadius.circular(10),
            borderSide: const BorderSide(color: Colors.deepOrange)),
      ),
    );
  }

  @override
  void dispose() {
    _nameC.dispose();
    _priceC.dispose();
    _descC.dispose();
    super.dispose();
  }
}

// ---- Edit Coffee Dialog ----
class _EditCoffeeDialog extends StatefulWidget {
  final CoffeeModel coffee;
  const _EditCoffeeDialog({required this.coffee});

  @override
  State<_EditCoffeeDialog> createState() => _EditCoffeeDialogState();
}

class _EditCoffeeDialogState extends State<_EditCoffeeDialog> {
  late TextEditingController _nameC, _priceC, _descC;
  late String _type;
  File? _pickedFile;
  late String _imagePath;
  bool _saving = false;

  @override
  void initState() {
    super.initState();
    _nameC = TextEditingController(text: widget.coffee.name);
    _priceC = TextEditingController(text: widget.coffee.price.toString());
    _descC = TextEditingController(text: widget.coffee.description);
    _type = widget.coffee.type;
    _imagePath = widget.coffee.image;
  }

  Future<void> _pickImage() async {
    final picked = await ImagePicker()
        .pickImage(source: ImageSource.gallery, imageQuality: 70);
    if (picked != null && mounted) {
      setState(() {
        _pickedFile = File(picked.path);
        _imagePath = picked.path;
      });
    }
  }

  void _save() async {
    setState(() => _saving = true);
    await CoffeeService().updateCoffee(widget.coffee.id, {
      'name': _nameC.text.trim(),
      'price': double.tryParse(_priceC.text) ?? widget.coffee.price,
      'description': _descC.text.trim(),
      'type': _type,
      'image': _imagePath,
    });
    if (mounted) Navigator.pop(context);
  }

  @override
  Widget build(BuildContext context) {
    return Dialog(
      backgroundColor: const Color(0xFF2d1a00),
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(20)),
      insetPadding:
          const EdgeInsets.symmetric(horizontal: 16, vertical: 24),
      child: SingleChildScrollView(
        padding: const EdgeInsets.all(20),
        child: Column(
          mainAxisSize: MainAxisSize.min,
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            const Text('Edit Coffee',
                style: TextStyle(
                    color: Colors.white,
                    fontSize: 20,
                    fontWeight: FontWeight.bold)),
            const SizedBox(height: 14),

            // Image
            GestureDetector(
              onTap: _pickImage,
              child: Container(
                width: double.infinity,
                height: 120,
                decoration: BoxDecoration(
                  borderRadius: BorderRadius.circular(14),
                  border: Border.all(
                      color: Colors.deepOrange.withOpacity(0.5)),
                ),
                child: ClipRRect(
                  borderRadius: BorderRadius.circular(14),
                  child: Stack(
                    fit: StackFit.expand,
                    children: [
                      _pickedFile != null
                          ? Image.file(_pickedFile!, fit: BoxFit.cover)
                          : _imagePath.startsWith('/')
                              ? Image.file(File(_imagePath),
                                  fit: BoxFit.cover,
                                  errorBuilder: (_, __, ___) =>
                                      Image.asset('assets/images/Coffee1.jpg',
                                          fit: BoxFit.cover))
                              : Image.asset(_imagePath, fit: BoxFit.cover,
                                  errorBuilder: (_, __, ___) => Container(
                                      color: Colors.deepOrange.withOpacity(0.2))),
                      Container(color: Colors.black38),
                      const Center(
                        child: Row(
                          mainAxisSize: MainAxisSize.min,
                          children: [
                            Icon(Icons.photo_library, color: Colors.white, size: 20),
                            SizedBox(width: 6),
                            Text('Change Image',
                                style: TextStyle(color: Colors.white, fontSize: 14)),
                          ],
                        ),
                      ),
                    ],
                  ),
                ),
              ),
            ),
            const SizedBox(height: 12),

            _buildField(_nameC, 'Name'),
            const SizedBox(height: 10),
            _buildField(_priceC, 'Price',
                keyboard: TextInputType.number),
            const SizedBox(height: 10),
            _buildField(_descC, 'Description', maxLines: 2),
            const SizedBox(height: 10),

            Container(
              padding: const EdgeInsets.symmetric(horizontal: 12),
              decoration: BoxDecoration(
                borderRadius: BorderRadius.circular(10),
                border: Border.all(color: Colors.white24),
              ),
              child: DropdownButton<String>(
                value: _type,
                isExpanded: true,
                dropdownColor: const Color(0xFF2d1a00),
                style: const TextStyle(color: Colors.white),
                underline: const SizedBox(),
                icon: const Icon(Icons.arrow_drop_down,
                    color: Colors.deepOrange),
                items: ['Hot Coffee', 'Cold Coffee', 'Desserts', 'Snacks']
                    .map((t) =>
                        DropdownMenuItem(value: t, child: Text(t)))
                    .toList(),
                onChanged: (v) => setState(() => _type = v!),
              ),
            ),
            const SizedBox(height: 20),

            Row(
              children: [
                Expanded(
                  child: OutlinedButton(
                    style: OutlinedButton.styleFrom(
                        side: const BorderSide(color: Colors.white24)),
                    onPressed: () => Navigator.pop(context),
                    child: const Text('Cancel',
                        style: TextStyle(color: Colors.white54)),
                  ),
                ),
                const SizedBox(width: 10),
                Expanded(
                  child: ElevatedButton(
                    style: ElevatedButton.styleFrom(
                        backgroundColor: Colors.deepOrange),
                    onPressed: _saving ? null : _save,
                    child: _saving
                        ? const SizedBox(
                            width: 20,
                            height: 20,
                            child: CircularProgressIndicator(
                                color: Colors.white, strokeWidth: 2))
                        : const Text('Save',
                            style: TextStyle(color: Colors.white)),
                  ),
                ),
              ],
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildField(TextEditingController c, String label,
      {TextInputType? keyboard, int maxLines = 1}) {
    return TextField(
      controller: c,
      keyboardType: keyboard,
      maxLines: maxLines,
      style: const TextStyle(color: Colors.white),
      decoration: InputDecoration(
        labelText: label,
        labelStyle: const TextStyle(color: Colors.white54),
        enabledBorder: OutlineInputBorder(
            borderRadius: BorderRadius.circular(10),
            borderSide: const BorderSide(color: Colors.white24)),
        focusedBorder: OutlineInputBorder(
            borderRadius: BorderRadius.circular(10),
            borderSide: const BorderSide(color: Colors.deepOrange)),
      ),
    );
  }

  @override
  void dispose() {
    _nameC.dispose();
    _priceC.dispose();
    _descC.dispose();
    super.dispose();
  }
}

// ---- Order Management ----
class _OrderManagementTab extends StatelessWidget {
  const _OrderManagementTab();

  @override
  Widget build(BuildContext context) {
    return StreamBuilder<List<OrderModel>>(
      stream: OrderService().getAllOrders(),
      builder: (context, snap) {
        if (snap.connectionState == ConnectionState.waiting) {
          return const Center(
              child: CircularProgressIndicator(color: Colors.deepOrange));
        }
        if (snap.hasError) {
          return Center(
              child: Text('Error: ${snap.error}',
                  style: const TextStyle(color: Colors.red)));
        }
        final orders = snap.data ?? [];
        if (orders.isEmpty) {
          return const Center(
              child: Text('No orders yet',
                  style: TextStyle(color: Colors.white54)));
        }
        return ListView.builder(
          padding: const EdgeInsets.all(16),
          itemCount: orders.length,
          itemBuilder: (context, i) =>
              _AdminOrderCard(order: orders[i]),
        );
      },
    );
  }
}

class _AdminOrderCard extends StatelessWidget {
  final OrderModel order;
  const _AdminOrderCard({required this.order});

  static const _statuses = [
    'pending', 'confirmed', 'preparing', 'out_for_delivery', 'delivered'
  ];

  static const _statusLabels = {
    'pending': 'Pending',
    'confirmed': 'Confirmed',
    'preparing': 'Preparing',
    'out_for_delivery': 'Out for Delivery',
    'delivered': 'Delivered',
  };

  static const _statusColors = {
    'pending': Colors.orange,
    'confirmed': Colors.blue,
    'preparing': Colors.purple,
    'out_for_delivery': Colors.teal,
    'delivered': Colors.green,
  };

  @override
  Widget build(BuildContext context) {
    final statusColor = _statusColors[order.status] ?? Colors.grey;

    return Container(
      margin: const EdgeInsets.only(bottom: 14),
      padding: const EdgeInsets.all(14),
      decoration: BoxDecoration(
        color: Colors.white.withOpacity(0.07),
        borderRadius: BorderRadius.circular(16),
        border: Border.all(color: Colors.white12),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          // Header row
          Row(
            children: [
              Expanded(
                child: Text(
                  'Order #${order.id.substring(0, 6).toUpperCase()}',
                  style: const TextStyle(
                      color: Colors.white,
                      fontWeight: FontWeight.bold,
                      fontSize: 15),
                ),
              ),
              Container(
                padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 3),
                decoration: BoxDecoration(
                  color: statusColor.withOpacity(0.2),
                  borderRadius: BorderRadius.circular(20),
                  border: Border.all(color: statusColor.withOpacity(0.5)),
                ),
                child: Text(
                  _statusLabels[order.status] ?? order.status,
                  style: TextStyle(
                      color: statusColor,
                      fontSize: 11,
                      fontWeight: FontWeight.bold),
                ),
              ),
            ],
          ),
          const SizedBox(height: 8),

          // Customer info
          _infoRow(Icons.person_outline, order.userName),
          _infoRow(Icons.phone_outlined, order.userPhone),
          _infoRow(Icons.location_on_outlined, order.userAddress),
          const Divider(color: Colors.white12, height: 16),

          // Items
          ...order.items.map((item) => Padding(
                padding: const EdgeInsets.only(bottom: 3),
                child: Row(
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  children: [
                    Expanded(
                      child: Text('• ${item.coffeeName} x${item.quantity}',
                          style: const TextStyle(
                              color: Colors.white60, fontSize: 12),
                          overflow: TextOverflow.ellipsis),
                    ),
                    Text(
                        '\$${(item.price * item.quantity).toStringAsFixed(2)}',
                        style: const TextStyle(
                            color: Colors.deepOrange, fontSize: 12)),
                  ],
                ),
              )),

          const Divider(color: Colors.white12, height: 12),
          Row(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: [
              const Text('Total:',
                  style: TextStyle(
                      color: Colors.white, fontWeight: FontWeight.bold)),
              Text('\$${order.totalAmount.toStringAsFixed(2)}',
                  style: const TextStyle(
                      color: Colors.deepOrange,
                      fontWeight: FontWeight.bold,
                      fontSize: 15)),
            ],
          ),
          const SizedBox(height: 10),

          // Status update dropdown
          Container(
            padding: const EdgeInsets.symmetric(horizontal: 12),
            decoration: BoxDecoration(
              color: Colors.deepOrange.withOpacity(0.1),
              borderRadius: BorderRadius.circular(10),
              border:
                  Border.all(color: Colors.deepOrange.withOpacity(0.4)),
            ),
            child: Row(
              children: [
                const Icon(Icons.update, color: Colors.deepOrange, size: 16),
                const SizedBox(width: 8),
                const Text('Update Status:',
                    style:
                        TextStyle(color: Colors.white70, fontSize: 12)),
                const SizedBox(width: 8),
                Expanded(
                  child: DropdownButton<String>(
                    value: order.status,
                    isExpanded: true,
                    dropdownColor: const Color(0xFF2d1a00),
                    style: const TextStyle(
                        color: Colors.white, fontSize: 13),
                    underline: const SizedBox(),
                    icon: const Icon(Icons.arrow_drop_down,
                        color: Colors.deepOrange),
                    items: _statuses
                        .map((s) => DropdownMenuItem(
                            value: s,
                            child: Text(_statusLabels[s] ?? s)))
                        .toList(),
                    onChanged: (newStatus) {
                      if (newStatus != null &&
                          newStatus != order.status) {
                        OrderService()
                            .updateOrderStatus(order.id, newStatus);
                        ScaffoldMessenger.of(context)
                            .showSnackBar(SnackBar(
                          content: Text(
                              'Status updated to: ${_statusLabels[newStatus]}'),
                          backgroundColor: Colors.deepOrange,
                        ));
                      }
                    },
                  ),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }

  Widget _infoRow(IconData icon, String text) {
    return Padding(
      padding: const EdgeInsets.only(bottom: 3),
      child: Row(
        children: [
          Icon(icon, color: Colors.deepOrange, size: 14),
          const SizedBox(width: 6),
          Expanded(
            child: Text(
              text.isEmpty ? 'Not provided' : text,
              style: TextStyle(
                  color:
                      text.isEmpty ? Colors.white30 : Colors.white60,
                  fontSize: 12),
              overflow: TextOverflow.ellipsis,
            ),
          ),
        ],
      ),
    );
  }
}
