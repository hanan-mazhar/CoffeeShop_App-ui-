import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../Models/order_model.dart';
import '../Services/auth_service.dart';
import '../Services/cart_provider.dart';
import '../Services/order_service.dart';
import '../Services/payment_service.dart';
import 'order_tracking_screen.dart';

class CartScreen extends StatefulWidget {
  const CartScreen({super.key});

  @override
  State<CartScreen> createState() => _CartScreenState();
}

class _CartScreenState extends State<CartScreen> {
  bool _placing = false;
  String _selectedPayment = 'cod'; // 'cod' ya 'card'

  // ── Cash on Delivery ───────────────────────────────────────────────────────
  Future<void> _placeOrderCOD(CartProvider cart) async {
    final user = AuthService().currentUser;
    if (user == null) { _snack('Pehle login karein'); return; }

    final userData = await AuthService().getUserData(user.uid);
    if (!mounted) return;
    if (userData == null) { _snack('User data nahi mila'); return; }
    if (userData.address.isEmpty) {
      _snack('Profile mein delivery address pehle add karein');
      return;
    }

    setState(() => _placing = true);

    final order = OrderModel(
      id: '',
      userId: user.uid,
      userName: userData.name,
      userAddress: userData.address,
      userPhone: userData.phone,
      items: List.from(cart.items),
      totalAmount: cart.totalAmount,
      status: 'pending',
      createdAt: DateTime.now(),
      paymentMethod: 'cod',
      paymentStatus: 'pending',
    );

    final orderId = await OrderService().placeOrder(order);
    setState(() => _placing = false);

    if (orderId != null && mounted) {
      cart.clearCart();
      Navigator.push(context,
          MaterialPageRoute(builder: (_) => OrderTrackingScreen(orderId: orderId)));
    } else if (mounted) {
      _snack('Order nahi ho saka. Dobara koshish karein.');
    }
  }

  // ── Card Payment (Stripe) ──────────────────────────────────────────────────
  Future<void> _placeOrderCard(CartProvider cart) async {
    final user = AuthService().currentUser;
    if (user == null) { _snack('Pehle login karein'); return; }

    final userData = await AuthService().getUserData(user.uid);
    if (!mounted) return;
    if (userData == null) { _snack('User data nahi mila'); return; }
    if (userData.address.isEmpty) {
      _snack('Profile mein delivery address pehle add karein');
      return;
    }

    setState(() => _placing = true);

    // Pehle order Firestore mein banao
    final order = OrderModel(
      id: '',
      userId: user.uid,
      userName: userData.name,
      userAddress: userData.address,
      userPhone: userData.phone,
      items: List.from(cart.items),
      totalAmount: cart.totalAmount,
      status: 'awaiting_payment',
      createdAt: DateTime.now(),
      paymentMethod: 'card',
      paymentStatus: 'pending',
    );

    final orderId = await OrderService().placeOrder(order);
    if (orderId == null) {
      setState(() => _placing = false);
      _snack('Order nahi ban saka. Dobara koshish karein.');
      return;
    }

    // Ab payment karo
    final result = await PaymentService().processPayment(
      amount: cart.totalAmount,
      userId: user.uid,
      orderId: orderId,
    );

    setState(() => _placing = false);
    if (!mounted) return;

    if (result.success) {
      await OrderService().updateOrderStatus(orderId, 'pending');
      cart.clearCart();
      _snack('Payment kamyab! ✅');
      Navigator.push(context,
          MaterialPageRoute(builder: (_) => OrderTrackingScreen(orderId: orderId)));
    } else {
      await OrderService().updateOrderStatus(orderId, 'payment_failed');
      _snack(result.errorMessage ?? 'Payment nahi hui.');
    }
  }

  void _checkout(CartProvider cart) {
    if (_selectedPayment == 'cod') {
      _placeOrderCOD(cart);
    } else {
      _placeOrderCard(cart);
    }
  }

  void _snack(String msg) {
    ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text(msg), backgroundColor: Colors.deepOrange));
  }

  @override
  Widget build(BuildContext context) {
    final cart = Provider.of<CartProvider>(context);
    final sw = MediaQuery.of(context).size.width;

    if (cart.items.isEmpty) {
      return Center(
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Icon(Icons.shopping_cart_outlined,
                size: sw * 0.2, color: Colors.white24),
            const SizedBox(height: 16),
            Text('Cart khali hai!',
                style: TextStyle(color: Colors.white54, fontSize: sw * 0.05)),
            const SizedBox(height: 8),
            const Text('Kuch order karein ☕',
                style: TextStyle(color: Colors.white30, fontSize: 14)),
          ],
        ),
      );
    }

    return Column(
      children: [
        // ── Items ────────────────────────────────────────────────────────────
        Expanded(
          child: ListView.builder(
            padding: EdgeInsets.all(sw * 0.04),
            itemCount: cart.items.length,
            itemBuilder: (context, i) {
              final item = cart.items[i];
              return Container(
                margin: const EdgeInsets.only(bottom: 12),
                padding: EdgeInsets.all(sw * 0.035),
                decoration: BoxDecoration(
                  color: Colors.white.withOpacity(0.07),
                  borderRadius: BorderRadius.circular(16),
                  border: Border.all(color: Colors.white12),
                ),
                child: Row(
                  children: [
                    ClipRRect(
                      borderRadius: BorderRadius.circular(10),
                      child: Image.asset(item.coffeeImage,
                          width: sw * 0.16,
                          height: sw * 0.16,
                          fit: BoxFit.cover,
                          errorBuilder: (_, __, ___) => Container(
                              width: sw * 0.16,
                              height: sw * 0.16,
                              color: Colors.deepOrange.withOpacity(0.2),
                              child: const Icon(Icons.coffee,
                                  color: Colors.deepOrange))),
                    ),
                    const SizedBox(width: 12),
                    Expanded(
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Text(item.coffeeName,
                              style: TextStyle(
                                  color: Colors.white,
                                  fontWeight: FontWeight.bold,
                                  fontSize: sw * 0.038),
                              maxLines: 1,
                              overflow: TextOverflow.ellipsis),
                          Text('Rs. ${item.price.toStringAsFixed(0)} each',
                              style: const TextStyle(
                                  color: Colors.white54, fontSize: 12)),
                        ],
                      ),
                    ),
                    Row(
                      children: [
                        _qtyBtn(Icons.remove,
                            () => cart.decreaseQuantity(item.coffeeId)),
                        Padding(
                          padding: const EdgeInsets.symmetric(horizontal: 10),
                          child: Text('${item.quantity}',
                              style: const TextStyle(
                                  color: Colors.white,
                                  fontSize: 16,
                                  fontWeight: FontWeight.bold)),
                        ),
                        _qtyBtn(
                            Icons.add,
                            () => cart.addItem(OrderItem(
                                  coffeeId: item.coffeeId,
                                  coffeeName: item.coffeeName,
                                  coffeeImage: item.coffeeImage,
                                  price: item.price,
                                ))),
                      ],
                    ),
                  ],
                ),
              );
            },
          ),
        ),

        // ── Payment + Summary Footer ──────────────────────────────────────────
        Container(
          padding: EdgeInsets.fromLTRB(sw * 0.05, 16, sw * 0.05, 24),
          decoration: BoxDecoration(
            color: Colors.black54,
            borderRadius:
                const BorderRadius.vertical(top: Radius.circular(24)),
            border: Border.all(color: Colors.white12),
          ),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              // Payment label
              const Text('Payment Method',
                  style: TextStyle(
                      color: Colors.white70,
                      fontSize: 13,
                      fontWeight: FontWeight.w600)),
              const SizedBox(height: 10),

              // COD / Card selector
              Row(
                children: [
                  Expanded(
                    child: _paymentTile(
                      value: 'cod',
                      icon: Icons.money,
                      label: 'Cash on\nDelivery',
                    ),
                  ),
                  const SizedBox(width: 12),
                  Expanded(
                    child: _paymentTile(
                      value: 'card',
                      icon: Icons.credit_card,
                      label: 'Card\nPayment',
                      badge: '🔒 Stripe',
                    ),
                  ),
                ],
              ),

              const SizedBox(height: 14),
              const Divider(color: Colors.white12),
              const SizedBox(height: 10),

              // Items count
              Row(
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                children: [
                  const Text('Items:', style: TextStyle(color: Colors.white60)),
                  Text('${cart.itemCount}',
                      style: const TextStyle(color: Colors.white)),
                ],
              ),
              const SizedBox(height: 6),

              // Total PKR
              Row(
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                children: [
                  const Text('Total:',
                      style: TextStyle(
                          color: Colors.white,
                          fontSize: 20,
                          fontWeight: FontWeight.bold)),
                  Text('Rs. ${cart.totalAmount.toStringAsFixed(0)}',
                      style: const TextStyle(
                          color: Colors.deepOrange,
                          fontSize: 22,
                          fontWeight: FontWeight.bold)),
                ],
              ),
              const SizedBox(height: 14),

              // Checkout button
              SizedBox(
                width: double.infinity,
                height: 52,
                child: ElevatedButton(
                  style: ElevatedButton.styleFrom(
                    backgroundColor: Colors.deepOrange,
                    shape: RoundedRectangleBorder(
                        borderRadius: BorderRadius.circular(14)),
                  ),
                  onPressed: _placing ? null : () => _checkout(cart),
                  child: _placing
                      ? const CircularProgressIndicator(color: Colors.white)
                      : Row(
                          mainAxisAlignment: MainAxisAlignment.center,
                          children: [
                            Icon(
                              _selectedPayment == 'card'
                                  ? Icons.credit_card
                                  : Icons.coffee,
                              color: Colors.white,
                            ),
                            const SizedBox(width: 8),
                            Text(
                              _selectedPayment == 'card'
                                  ? 'Pay Rs. ${cart.totalAmount.toStringAsFixed(0)}'
                                  : 'Order Karein ☕',
                              style: const TextStyle(
                                  fontSize: 18,
                                  fontWeight: FontWeight.bold,
                                  color: Colors.white),
                            ),
                          ],
                        ),
                ),
              ),
            ],
          ),
        ),
      ],
    );
  }

  Widget _paymentTile({
    required String value,
    required IconData icon,
    required String label,
    String? badge,
  }) {
    final selected = _selectedPayment == value;
    return GestureDetector(
      onTap: () => setState(() => _selectedPayment = value),
      child: AnimatedContainer(
        duration: const Duration(milliseconds: 200),
        padding: const EdgeInsets.symmetric(vertical: 12, horizontal: 10),
        decoration: BoxDecoration(
          color: selected
              ? Colors.deepOrange.withOpacity(0.18)
              : Colors.white.withOpacity(0.05),
          borderRadius: BorderRadius.circular(14),
          border: Border.all(
            color: selected ? Colors.deepOrange : Colors.white24,
            width: selected ? 2 : 1,
          ),
        ),
        child: Column(
          children: [
            Icon(icon,
                color: selected ? Colors.deepOrange : Colors.white54,
                size: 26),
            const SizedBox(height: 6),
            Text(label,
                textAlign: TextAlign.center,
                style: TextStyle(
                    color: selected ? Colors.white : Colors.white60,
                    fontSize: 12,
                    fontWeight:
                        selected ? FontWeight.bold : FontWeight.normal)),
            if (badge != null) ...[
              const SizedBox(height: 4),
              Container(
                padding:
                    const EdgeInsets.symmetric(horizontal: 6, vertical: 2),
                decoration: BoxDecoration(
                  color: Colors.deepOrange.withOpacity(0.2),
                  borderRadius: BorderRadius.circular(8),
                ),
                child: Text(badge,
                    style: const TextStyle(
                        color: Colors.deepOrange, fontSize: 10)),
              ),
            ],
          ],
        ),
      ),
    );
  }

  Widget _qtyBtn(IconData icon, VoidCallback onTap) {
    return GestureDetector(
      onTap: onTap,
      child: Container(
        width: 30,
        height: 30,
        decoration: BoxDecoration(
          color: Colors.deepOrange.withOpacity(0.2),
          shape: BoxShape.circle,
          border: Border.all(color: Colors.deepOrange.withOpacity(0.5)),
        ),
        child: Icon(icon, color: Colors.deepOrange, size: 16),
      ),
    );
  }
}
